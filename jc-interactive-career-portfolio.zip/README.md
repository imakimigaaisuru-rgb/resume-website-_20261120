# JC Portfolio V2 | 互動式個人履歷網站

這是可離線開啟的靜態個人履歷網站，使用 HTML、CSS、JavaScript，不需要安裝任何套件或伺服器。

## 開啟網站

解壓縮後，用 Chrome、Edge 或 Safari 開啟 `index.html`。也可以把 `index.html` 上傳到 GitHub Pages 發布。

## V2 更新 | 互動式職涯時間軸

- 2017 年至今 7 段主要正式經歷，以時間先後顯示。
- 點選左側年表節點（手機版為橫向滑動卡片），右側即切換職稱、公司、工作內容與核心技能。
- 使用 `←` / `→` 按鈕翻閱職涯；鍵盤焦點位於年表時也能使用方向鍵、Home、End。
- 「展開全部經歷」可以一次閱讀所有工作內容。
- 繁體中文 / 日文均提供時間軸翻譯，切換後保留所選工作階段。
- 列印或儲存 PDF 時，會顯示全部職涯資料，而非僅顯示當前選取項目。
- 未加入個人照片。

## 其他功能

- 繁體中文 / 日文切換
- 深色 / 淺色主題
- 案例分類篩選
- RWD 手機與桌面版
- 避免公開私人電話、精確住址、薪資及客戶機密

## 修改內容

網站文字在 `index.html` 底部的 `data.zh` / `data.ja` 中。時間軸能力標籤在 `careerExtras.zh` / `careerExtras.ja`，編修工作經歷時應同步維護。

## GitHub Pages 部署

1. 新增 GitHub Repository，例如 `jc-portfolio`。
2. 上傳 `index.html` 至 Repository 根目錄。
3. 於 Settings → Pages 選擇 Deploy from a branch → `main` → `/ (root)`。
4. 取得網站網址後就能分享，後續更新直接替換 `index.html`。

**注意：** 104 分享履歷連結有時效性（通常 14 天）。網站中既有的 104 連結可能需要日後替換。
